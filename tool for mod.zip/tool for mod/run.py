import os
import shutil
for i in range(20):
	os.system('py tao_list_tu_dong.py')
	os.system('py main.py ver{} t t s'.format(str(i)))
	folder_name='MODSKINPRO/PACK ver{} MODSKINPRO'.format(str(i))
	os.system('py tachfilemsp.py ver{} ver{}'.format(str(i),str(i)))
	shutil.make_archive(folder_name, 'zip', folder_name)
	if os.path.exists(folder_name):
		shutil.rmtree(folder_name)