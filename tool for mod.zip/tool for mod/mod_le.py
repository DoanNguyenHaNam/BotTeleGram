import os
from __init__ import *
txt=open('list_mod.txt','r')
for ID in txt:
    ID=ID.replace(' ','').replace('\n','')
    print(ID)
    with open('list_mod_le.txt','w') as f:f.write(ID)
    a,name=ten_skin_hieu_ung(int(ID))
    print('py main_mod_le.py '+name.replace(' ','_')+' t t s')
    os.system('py main_mod_le.py '+name.replace(' ','_')+' t t s')